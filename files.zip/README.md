# Ray-Ban Meta Display + Pressure Data Glove Integration

A real-time multimodal wearable system combining Meta Ray-Ban smart glasses with a pressure sensor glove for rehabilitation and HCI research. This project implements a Tower of Hanoi game that runs simultaneously on glasses display and desktop UI, with real-time fusion of:

- **Vision**: Ray-Ban Meta Display (400×400px in-lens monocular display)
- **Tactile Feedback**: 40-sensor pressure glove (ESP32-S3 via UDP)
- **Game Logic**: Flask server with Hanoi solver
- **Real-Time Updates**: 200ms polling, 5 updates/second

## Features

- ✅ **Glasses-Optimized UI** - Designed for 400×400px monocular display
- ✅ **Real-Time Pressure Feedback** - Live finger state updates
- ✅ **Ring Detection** - Automatic ring identification from finger pressure patterns
- ✅ **Game State Synchronization** - Seamless glove ↔ server ↔ glasses data flow
- ✅ **REST API** - `/api/state` endpoint for UI updates
- ✅ **Network-Agnostic** - Works over WiFi with configurable IPs
- ✅ **Rehabilitation-Ready** - Designed for motor control assessment

## Architecture

```
Pressure Glove (ESP32-S3)
     ↓ UDP 15002
Receiver (receive.py)
     ↓
Flask App (Port 5000)
     ├→ Game Logic
     ├→ Hand Detection  
     └→ Ring Tracking
     ↓
Ray-Ban Meta Display
     ↓ HTTP GET /api/state (200ms polling)
Real-Time Glasses UI (400×400px)
```

## System Requirements

### Hardware
- **Ray-Ban Meta Display Glasses** (with WiFi)
- **ESP32-S3 Microcontroller** (for glove)
- **40-Sensor Pressure Matrix** (textile-based or FSR array)
- **PC/Mac** (Flask server)

### Software
- Python 3.8+
- Flask
- NumPy
- (Optional) receive.py for UDP middleware

## Installation

### 1. Clone Repository
```bash
git clone https://github.com/yourusername/rayban-dataglove-hanoi.git
cd rayban-dataglove-hanoi
```

### 2. Create Virtual Environment
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# macOS/Linux
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install flask numpy
```

### 4. Configure Network
Edit `.env` or set environment variables:
```bash
export UDP_HOST=127.0.0.1      # Flask listening address
export UDP_PORT=53000           # UDP receiver port
```

### 5. Verify Glove Connection
- ESP32 firmware must target your PC IP
- Check: `ipconfig` (Windows) or `ifconfig` (Linux/Mac)
- Glove ESP32 must be on same WiFi network

## Quick Start

### Running the System

```bash
# Start Flask server (also starts UDP receiver)
python app.py

# Output should show:
# [UDP] Listening on 127.0.0.1:53000
# Running on http://127.0.0.1:5000
```

### Access from Glasses

1. Ensure Ray-Ban Meta Display is connected to WiFi (same network as PC)
2. Open browser in Meta View app
3. Navigate to: `http://192.168.1.105:5000/glasses` (replace with your PC IP)
4. Bookmark for quick access

### Test on Desktop

```bash
# Resize browser window to 400×400px
# Or open DevTools and set custom device size
# Navigate to: http://192.168.1.105:5000/glasses
```

## Project Structure

```
rayban-dataglove-hanoi/
├── app.py                 # Main Flask app with Hanoi game
├── sensor.py             # Packet parser for glove data
├── receive.py            # Optional UDP middleware
├── README.md             # This file
├── LICENSE               # MIT License
├── requirements.txt      # Python dependencies
├── .env.example          # Environment variables template
├── docs/
│   ├── ARCHITECTURE.md   # System design details
│   ├── SETUP_GUIDE.md    # Step-by-step setup
│   ├── API.md            # REST API documentation
│   └── GLASSES_UI.md     # Glasses display specifications
└── firmware/
    ├── old_glove.ino     # Old glove ESP32-S3 firmware
    └── pressure_sheet.ino # Pressure sheet firmware (optional)
```

## REST API

### GET `/api/state`
Get current game state (called every 200ms by glasses UI)

**Response:**
```json
{
  "instruction": "Pick ring 1 from peg A and place it on peg B",
  "expected_move": {
    "ring": 1,
    "source": "A",
    "target": "B"
  },
  "frame": {
    "packet_count": 1247,
    "packets_per_second": 98.5,
    "pressure": [450, 320, 0, ...],
    "max_pressure": 650,
    "mean_pressure": 125.5
  },
  "detect": {
    "finger_values": {"thumb": 450, "index": 0, ...},
    "finger_active": {"thumb": true, "index": false, ...},
    "active_finger_count": 1,
    "ring_candidate": 1,
    "status": "Waiting for ring 1 pickup"
  },
  "game": {
    "pegs": {"A": [4,3,2,1], "B": [], "C": []},
    "move_index": 0,
    "in_hand": null,
    "completed": false
  }
}
```

### POST `/api/reset`
Reset game to initial state

**Response:**
```json
{"ok": true}
```

## Configuration

### Finger Sensor Mapping
Edit `FINGER_SENSOR_IDS` in `app.py`:
```python
FINGER_SENSOR_IDS = {
    "thumb": 0,     # Sensor 0 = thumb pressure
    "index": 1,     # Sensor 1 = index finger
    "middle": 2,
    "ring": 3,
    "little": 4,
}
```

### Pressure Thresholds
Adjust `FINGER_THRESHOLD` for sensitivity:
```python
FINGER_THRESHOLD = {
    "thumb": 550,   # Pressure value to activate
    "index": 550,
    # ...
}
```

### Ring Detection Logic
The system uses finger activation count to infer ring:
```python
RING_BY_ACTIVE_COUNT = {
    2: 1,  # 2 active fingers = ring 1
    3: 2,  # 3 active fingers = ring 2
    4: 3,  # etc.
    5: 4,
}
```

## How It Works

### Game Flow

1. **Finger Detection** - Pressure glove detects which fingers are active
2. **Ring Inference** - Number of active fingers → ring ID
3. **Pickup Validation** - Checks if ring matches expected move
4. **State Update** - Ring moves in game state
5. **Display Update** - Glasses display refreshes (200ms polling)
6. **Release Detection** - All fingers released → move commits

### Glasses Display Updates

- **Real-time** - Polls `/api/state` every 200ms
- **Non-blocking** - Uses fetch with cache-no-store
- **Responsive** - Updates visible within ~500ms of glove input
- **Battery-friendly** - 5 updates/sec (not higher)

## Troubleshooting

### Glasses Display Not Loading
```
Error: Connection refused / Timeout

1. Check Flask is running:
   python app.py

2. Verify PC IP address:
   Windows: ipconfig
   Linux/Mac: ifconfig

3. Ensure glasses on same WiFi:
   Meta View app → Settings → WiFi
```

### Finger Emojis Not Updating
```
Issue: Pressure glove active but display doesn't respond

1. Check Flask console for UDP packets:
   Should show "[UDP] Listening on 127.0.0.1:53000"

2. Verify glove ESP32 target IP:
   Should send to your PC IP (e.g., 192.168.1.105)

3. Check firewall:
   Windows Defender → Allow Python through firewall
```

### Display Too Small/Large
```
Zoom in glasses browser:
- Ctrl + Plus (increase)
- Ctrl + Minus (decrease)

Or edit CSS in GLASSES_HTML section of app.py
```

## Performance Metrics

- **Update Latency**: ~200-500ms (glove touch → glasses display)
- **Frame Rate**: 5 updates/second
- **Packet Rate**: ~100 packets/second from glove
- **Memory**: ~50MB (Python process)
- **CPU**: <5% single-core usage

## Development

### Adding New Gestures
Extend `RING_BY_ACTIVE_COUNT` and update game logic in `update_detection_locked()`.

### Customizing Hanoi Puzzle
The `solve_hanoi()` function generates moves. Modify to:
- Change ring count (default: 4)
- Change source/destination pegs
- Add custom puzzle logic

### Extending the UI
The `/glasses` endpoint renders HTML from `GLASSES_HTML` string. Modify CSS/JS for:
- Different layout
- Additional metrics
- Custom styling
- Animation effects

## Research Applications

This system is designed for:

- **Motor Rehabilitation** - Assess fine motor control through ring manipulation
- **HCI Research** - Study multimodal interaction (vision + tactile)
- **Cognitive Assessment** - Tower of Hanoi as cognitive load measure
- **Wearable Computing** - Proof-of-concept AR glasses integration
- **Real-Time Feedback Systems** - Low-latency sensor fusion

## Hardware Setup

### Pressure Glove (ESP32-S3)
- 40 pressure sensors arranged in 8×5 matrix
- UDP packets at ~100Hz
- 208-byte packets with sensor data + IMU
- Device ID: 0x11

### Optional: Pressure Sheet
- 70-sensor matrix on physical surface
- For ring placement detection
- Device ID: 0x31
- UDP packets at ~50Hz

### Network Configuration
```
         WiFi Network (192.168.1.x)
              /    |    \
        Glove   Flask   Glasses
    192.168.1.112  .105  (dynamic)
```

## License

MIT License - see LICENSE file

## Citation

If you use this system in research, please cite:

```bibtex
@software{rayban_dataglove_2024,
  author = {Your Name},
  title = {Ray-Ban Meta Display and Data Glove Integration for Rehabilitation},
  year = {2024},
  url = {https://github.com/yourusername/rayban-dataglove-hanoi}
}
```

## Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/your-feature`)
3. Commit changes (`git commit -am 'Add your feature'`)
4. Push to branch (`git push origin feature/your-feature`)
5. Open a Pull Request

## Roadmap

- [ ] Phase 2: Vision AI integration (detect ring positions from camera)
- [ ] Phase 3: Neural Band gesture control (EMG wristband input)
- [ ] Phase 4: Advanced ring tracking (3D hand pose estimation)
- [ ] Phase 5: Multiplayer support (multiple glasses displays)
- [ ] Phase 6: Mobile app for data collection

## Support

- 📖 **Documentation**: See `docs/` folder
- 🐛 **Issues**: GitHub Issues page
- 💬 **Discussions**: GitHub Discussions
- 📧 **Email**: (your contact info)

## Acknowledgments

- Ray-Ban Meta Display SDK by Meta/Facebook
- Flask web framework
- ESP32-S3 Arduino framework
- Tower of Hanoi puzzle algorithm

---

**Last Updated**: 2025-06-05  
**Maintained By**: (Your Name)  
**Status**: ✅ Active Development
